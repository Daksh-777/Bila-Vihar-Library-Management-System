Bala Vihar Library Management System  
----------------------------  

Python Version: 3.x  
Required Modules: tkinter, os, suprocess, sys, re, sqlite3, logging

How to Run the Application:  
1. Extract the ZIP file.  
2. Open the extracted folder.  
3. Ensure that all `.py` files and required images are in the same folder.  
4. Open a terminal or command prompt in the folder.  
5. Run the following command:  
   ```bash
   python login.py